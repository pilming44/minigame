package toy.project.minigame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinigameApplication {

	public static void main(String[] args) {
		SpringApplication.run(MinigameApplication.class, args);
	}

}
