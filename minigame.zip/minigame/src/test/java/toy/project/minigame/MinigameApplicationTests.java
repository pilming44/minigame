package toy.project.minigame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinigameApplicationTests {

	@Test
	void contextLoads() {
	}

}
